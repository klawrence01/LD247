// src/app/city/page.tsx
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Browse Cities • Local Deals 24/7",
};

type CityRow = { city: string; count: number };

// If you're already fetching this from Supabase, keep that code;
// this mock is just to keep the example self-contained.
async function getCities(): Promise<CityRow[]> {
  // Replace with your real SELECT over city_active_deals grouped by city
  // e.g., select city, count(*) from city_active_deals group by city order by city
  return [
    { city: "atlanta", count: 1 },
    { city: "boston", count: 1 },
    { city: "hartford", count: 1 },
    { city: "new-york", count: 1 },
  ];
}

function prettyCity(slug: string) {
  return slug
    .split("-")
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join("-");
}

export default async function CityIndexPage() {
  const cities = await getCities();

  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      <h1 className="text-4xl font-bold tracking-tight mb-6">Browse Cities</h1>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {cities.map((c) => (
          <Link
            key={c.city}
            href={`/city/${c.city}`}                 // <-- IMPORTANT: /city/<slug>
            className="group block rounded-xl border p-5 transition hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <div className="flex items-start justify-between">
              <h2 className="text-xl font-semibold text-gray-900">
                {prettyCity(c.city)}
              </h2>
              <span className="text-sm text-gray-500">
                {c.count} {c.count === 1 ? "deal" : "deals"}
              </span>
            </div>
            <p className="mt-3 text-blue-600 group-hover:underline">
              See today’s deals →
            </p>
          </Link>
        ))}
      </div>
    </main>
  );
}
