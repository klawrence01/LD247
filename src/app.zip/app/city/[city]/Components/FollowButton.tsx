// TODO: Build [FollowButton] component
