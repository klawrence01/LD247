// TODO: Build [Citybanner] component
