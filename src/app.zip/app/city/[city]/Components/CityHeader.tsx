// TODO: Build [CityHeader] component
