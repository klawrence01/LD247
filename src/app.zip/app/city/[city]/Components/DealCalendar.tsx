// TODO: Build [DealCalendar] component
