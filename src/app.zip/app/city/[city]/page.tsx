// src/app/city/[city]/page.tsx
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { getSupabaseServer } from "@/lib/supabaseServer";

type PageProps = { params: { city: string } };

// --- helpers -------------------------------------------------
function normalizeCity(slug: string) {
  return slug.toLowerCase();
}
function niceCity(slug: string) {
  const s = slug.replace(/-/g, " ");
  return s.replace(/\b\w/g, (c) => c.toUpperCase());
}

// --- metadata ------------------------------------------------
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const city = niceCity(params.city);
  return {
    title: `${city} Deals`,
    description: `Today’s local deals in ${city}.`,
  };
}

// What we’ll render from the view
type CityDealRow = {
  city: string;
  title: string;
  price_text: string | null;
  image_url: string | null;
};

async function fetchCityDeals(citySlug: string): Promise<CityDealRow[]> {
  const city = normalizeCity(citySlug);
  const supabase = getSupabaseServer();

  // IMPORTANT: Only ask for columns the view has
  const { data, error } = await supabase
    .from("city_active_deals")
    .select("city, title, price_text, image_url")
    .eq("city", city)
    .order("title", { ascending: true });

  if (error) {
    console.error("fetchCityDeals error:", error);
    return [];
  }
  return (data ?? []) as CityDealRow[];
}

// --- page ----------------------------------------------------
export default async function CityPage({ params }: PageProps) {
  const citySlug = params.city;
  const cityPretty = niceCity(citySlug);

  const deals = await fetchCityDeals(citySlug);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      {/* Heading */}
      <header className="mb-6">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
          {cityPretty.toUpperCase()}
        </h1>
        <p className="text-muted-foreground mt-2 text-lg">
          Everyday Deals. Everyday Heroes.
        </p>
      </header>

      {/* Results */}
      {deals.length === 0 ? (
        <div className="rounded-lg border bg-muted/40 px-4 py-10 text-center text-muted-foreground">
          No active deals found for{" "}
          <span className="font-semibold">{cityPretty}</span>.
        </div>
      ) : (
        <ul className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {deals.map((d, idx) => (
            <li key={`${d.title}-${idx}`}>
              <article className="overflow-hidden rounded-xl border bg-background shadow-sm hover:shadow-md transition">
                {/* Image */}
                <div className="relative h-48 w-full bg-muted">
                  <Image
                    src={d.image_url || "https://picsum.photos/seed/placeholder/640/420"}
                    alt={d.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                  />
                </div>

                {/* Body */}
                <div className="p-4">
                  <h3 className="text-lg font-semibold leading-tight">{d.title}</h3>

                  {/* Category/rating placeholders (can wire up later) */}
                  <div className="mt-1 text-sm text-muted-foreground">
                    Food &amp; Beverage
                  </div>

                  {/* Price text */}
                  {d.price_text && (
                    <div className="mt-3 font-semibold">{d.price_text}</div>
                  )}

                  {/* CTA to detail page (wire when deal detail route is ready) */}
                  <div className="mt-4">
                    <Link
                      href="#"
                      className="inline-flex items-center rounded-md border px-3 py-1.5 text-sm hover:bg-muted"
                    >
                      View Deal
                    </Link>
                  </div>
                </div>
              </article>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
