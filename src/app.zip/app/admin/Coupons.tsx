export default function AdminCoupons() {
  return <div>Coupon Management</div>;
}
