export default function AdminLogs() {
  return <div>System Logs</div>;
}
