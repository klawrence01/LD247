export default function AdminUsers() {
  return <div>User Management</div>;
}
