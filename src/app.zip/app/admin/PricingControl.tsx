export default function AdminPricingControl() {
  return <div>Pricing Control Panel</div>;
}
