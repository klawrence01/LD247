export default function AdminApprovals() {
  return <div>Vendor Approvals</div>;
}
