export default function AdminReports() {
  return <div>Analytics and Reports</div>;
}
