import CityHeader from "@/components/city/CityHeader"

export default function AtlantaPage() {
  return (
    <main className="p-6">
      <CityHeader city="Atlanta" tagline="Hand-picked deals from local favorites." />

      {/* Placeholder content — swap for your feed later */}
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <h2 className="text-lg font-semibold">Featured Today</h2>
        <p className="text-gray-600 text-sm mt-1">
          This is a placeholder city page. Your live feed goes here.
        </p>
      </div>
    </main>
  )
}
