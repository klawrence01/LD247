"use client";

import styles from "./HeroBanner.module.css";

type Props = {
  title: string;
  subtitle?: string;
  ctaText?: string;
  scrollTargetId?: string; // <-- pass an id, not a function
};

export default function HeroBanner({ title, subtitle, ctaText, scrollTargetId }: Props) {
  const onCtaClick = () => {
    if (!scrollTargetId) return;
    const el = document.getElementById(scrollTargetId);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section className={styles.hero}>
      <div className={styles.inner}>
        <h1 className={styles.title}>{title}</h1>
        {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
        {ctaText && (
          <button className={styles.cta} onClick={onCtaClick}>
            {ctaText}
          </button>
        )}
      </div>
    </section>
  );
}
