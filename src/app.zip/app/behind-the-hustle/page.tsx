import Link from "next/link";
import { blogPosts } from "../../data/behindTheHustle";

export default function BehindTheHustle() {
  return (
    <main className="p-8 max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">Behind the Hustle</h1>
      <div className="grid gap-6">
        {blogPosts.map((post) => (
          <Link key={post.id} href={`/behind-the-hustle/${post.id}`}>
            <div className="p-6 border rounded-xl hover:shadow transition">
              <h2 className="text-2xl font-semibold">{post.title}</h2>
              <p className="text-sm text-gray-500">{new Date(post.date).toDateString()}</p>
              <p className="mt-2 text-gray-700">{post.teaser}</p>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
