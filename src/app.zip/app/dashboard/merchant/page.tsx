// app/dashboard/merchant/page.tsx

import Link from "next/link";

export const metadata = {
  title: "Merchant Dashboard",
  description: "Manage your business, deals, and discover resources to grow.",
};

export default function MerchantDashboard() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">Welcome Back!</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Everyday Heroes Blog Link */}
        <Link
          href="/everyday-heroes"
          className="block bg-orange-50 hover:bg-orange-100 border-l-4 border-orange-500 rounded-xl p-5 shadow transition-all"
        >
          <h2 className="text-xl font-bold text-orange-600 mb-1">Everyday Heroes</h2>
          <p className="text-sm text-gray-700">
            See how local business owners like you are growing, thriving, and getting the love they deserve.
          </p>
        </Link>

        {/* Add other dashboard cards here */}
        <Link
          href="/dashboard/merchant/deals"
          className="block bg-white hover:bg-gray-100 border border-gray-200 rounded-xl p-5 shadow transition"
        >
          <h2 className="text-xl font-semibold text-gray-800 mb-1">Manage Your Deals</h2>
          <p className="text-sm text-gray-600">Create, update, or track your current promotions.</p>
        </Link>

        <Link
          href="/dashboard/merchant/analytics"
          className="block bg-white hover:bg-gray-100 border border-gray-200 rounded-xl p-5 shadow transition"
        >
          <h2 className="text-xl font-semibold text-gray-800 mb-1">View Analytics</h2>
          <p className="text-sm text-gray-600">See how your deals are performing and how customers are engaging.</p>
        </Link>

        {/* More cards can be added here */}
      </div>
    </div>
  );
}
