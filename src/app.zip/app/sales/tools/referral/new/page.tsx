import ReferralForm from "@/components/referral/ReferralForm";

export default function NewReferralPage() {
  return (
    <div className="p-6 md:p-10">
      <ReferralForm />
    </div>
  );
}
