// C:\Users\Owner\ld247\src\app\sales\page.tsx
import Link from "next/link";

export default function SalesPage() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Sales Tools</h1>
      <p className="text-gray-600">Fast demos. Clean conversations. Close kindly.</p>

      <section className="rounded-2xl border p-4 space-y-2">
        <h2 className="text-xl font-semibold">Quick Demo Links</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li><Link href="/atlanta">City Page — Atlanta</Link></li>
          <li><Link href="/vendor">Merchant Page — Tony’s Pizza</Link></li>
        </ul>
      </section>

      <section className="rounded-2xl border p-4 space-y-2">
        <h2 className="text-xl font-semibold">Referral Pitch (Static)</h2>
        <p>
          We can list your business for free, run referral-based coupons on your slow
          hours, and only charge a small fee on redemptions. Zero risk, upside only.
        </p>
      </section>
    </main>
  );
}
