// app/everyday-heroes/page.tsx

import Link from "next/link";
import { getPostMetadata } from "@/lib/posts";

export const metadata = {
  title: "Everyday Heroes",
  description: "Real stories from merchants who are making a difference.",
};

export default async function EverydayHeroes() {
  const posts = await getPostMetadata("everyday-heroes");

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-orange-600">Everyday Heroes</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {posts.map((post) => (
          <Link
            key={post.slug}
            href={`/everyday-heroes/${post.slug}`}
            className="border-l-4 border-orange-500 bg-white rounded-lg p-5 shadow-md hover:shadow-lg transition"
          >
            <h2 className="text-xl font-semibold mb-2">{post.title}</h2>
            <p className="text-sm text-gray-500 italic">{post.date}</p>
            <p className="text-sm mt-2 text-gray-700 line-clamp-3">{post.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
