import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { createClient } from "@supabase/supabase-js";

export const revalidate = 300; // revalidate every 5 minutes

type PageProps = { params: { id: string } };

type Vendor = {
  id: string;
  name: string | null;
  logo_url: string | null;
  website: string | null;
};

type Deal = {
  id: string;
  title: string | null;
  description: string | null;
  category: string | null;
  city: string | null;
  image_url: string | null;
  price: number | null;
  original_price: number | null;
  status: string | null;
  start_date: string | null;
  end_date: string | null;
  vendors: Vendor | null;
};

function sb() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { auth: { persistSession: false } }
  );
}

async function fetchDeal(id: string): Promise<Deal | null> {
  const { data, error } = await sb()
    .from("deals")
    .select(
      `
      id,
      title,
      description,
      category,
      city,
      image_url,
      price,
      original_price,
      status,
      start_date,
      end_date,
      vendors:vendor_id (
        id,
        name,
        logo_url,
        website
      )
    `
    )
    .eq("id", id)
    .maybeSingle();

  if (error) {
    console.error("fetchDeal error:", error);
    return null;
  }

  return (data as Deal) ?? null;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const deal = await fetchDeal(params.id);
  if (!deal) return { title: "Deal not found • Local Deals 24/7" };
  const title = `${deal.title ?? "Deal"} • ${deal.city ?? "Local"} • Local Deals 24/7`;
  const description =
    deal.description ??
    (deal.price != null && deal.original_price != null
      ? `Now $${deal.price.toFixed(2)} (was $${deal.original_price.toFixed(2)})`
      : "Find today’s local deal.");

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: deal.image_url ? [deal.image_url] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
    },
  };
}

export default async function DealPage({ params }: PageProps) {
  const deal = await fetchDeal(params.id);
  if (!deal) notFound();

  const priceText =
    deal.price != null && deal.original_price != null
      ? `$${deal.price.toFixed(2)} (was $${deal.original_price.toFixed(2)})`
      : deal.price != null
      ? `$${deal.price.toFixed(2)}`
      : null;

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      {/* City + Title */}
      <div className="mb-2 text-sm text-gray-500">
        {deal.city ? (
          <>
            <Link href={`/city/${deal.city.toLowerCase()}`} className="underline">
              {deal.city}
            </Link>{" "}
            • {deal.category ?? "Deal"}
          </>
        ) : (
          deal.category ?? "Deal"
        )}
      </div>

      <h1 className="mb-4 text-3xl font-semibold">{deal.title ?? "Deal"}</h1>

      {/* Vendor — clickable to vendor page */}
      {deal.vendors && (
        <Link
          href={`/vendor/${deal.vendors.id}`}
          className="mb-6 flex items-center gap-3"
        >
          <div className="relative h-10 w-10 overflow-hidden rounded-full bg-gray-200">
            <Image
              src={deal.vendors.logo_url || "https://picsum.photos/seed/vendor/100/100"}
              alt={deal.vendors.name || "Vendor"}
              fill
              className="object-cover"
              sizes="40px"
            />
          </div>
          <div className="text-blue-600 underline underline-offset-2">
            {deal.vendors.name ?? "Vendor"}
          </div>
        </Link>
      )}

      {/* Hero image */}
      <div className="relative mb-6 aspect-[16/9] overflow-hidden rounded-xl bg-gray-100">
        <Image
          src={deal.image_url || "https://picsum.photos/seed/deal/1200/675"}
          alt={deal.title ?? ""}
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Details card */}
      <div className="rounded-xl border bg-white p-5">
        {priceText && <div className="mb-2 text-lg font-semibold">{priceText}</div>}

        {deal.description && (
          <p className="mb-4 whitespace-pre-line text-gray-800">{deal.description}</p>
        )}

        <dl className="grid gap-2 text-sm text-gray-600 sm:grid-cols-2">
          <div>
            <dt className="font-medium text-gray-700">Status</dt>
            <dd className="capitalize">{deal.status ?? "published"}</dd>
          </div>
          <div>
            <dt className="font-medium text-gray-700">City</dt>
            <dd>{deal.city ?? "Local"}</dd>
          </div>
          <div>
            <dt className="font-medium text-gray-700">Start</dt>
            <dd>{deal.start_date ?? "—"}</dd>
          </div>
          <div>
            <dt className="font-medium text-gray-700">End</dt>
            <dd>{deal.end_date ?? "—"}</dd>
          </div>
        </dl>

        {/* Optional vendor website */}
        {deal.vendors?.website && (
          <div className="mt-4">
            <a
              href={deal.vendors.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-blue-600 underline"
            >
              Visit vendor website
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
