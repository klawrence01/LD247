// src/app/layout.tsx
import "./globals.css";
import { Inter } from "next/font/google";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Local Deals 24/7",
  description: "Built for Small Business Heroes.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SiteHeader />
        {/* Keep exactly one <main> in the whole app */}
        <main className="min-h-[60vh] px-6 py-8">{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
