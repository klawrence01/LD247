"use client";
import { useEffect, useMemo, useState } from "react";

type Props = {
  baseDate?: Date;                 // Defaults to today
  onSelectDate?: (d: Date) => void; // Optional callback when date changes
};

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function sameDay(a: Date, b: Date) {
  return a.toDateString() === b.toDateString();
}

export default function MiniCalendar({ baseDate, onSelectDate }: Props) {
  const today = startOfDay(new Date());
  const [selected, setSelected] = useState<Date>(startOfDay(baseDate ?? today));

  // 7-day window centered on selected day (index 4)
  const windowDays = useMemo(() => {
    const center = startOfDay(selected);
    const days: Date[] = [];
    for (let i = -3; i <= 3; i++) days.push(addDays(center, i));
    return days;
  }, [selected]);

  useEffect(() => {
    // Fire browser event for global listeners (DealsClient)
    window.dispatchEvent(new CustomEvent("ld247:dateChange", { detail: { date: selected } }));
    if (onSelectDate) onSelectDate(selected);
  }, [selected, onSelectDate]);

  const setToday = () => setSelected(today);
  const setTomorrow = () => setSelected(addDays(today, 1));
  const setWeekend = () => {
    const dow = today.getDay(); // 0 Sun .. 6 Sat
    const delta = (6 - dow + 7) % 7;
    setSelected(addDays(today, delta));
  };

  return (
    <div className="w-full">
      <div className="flex gap-2 mb-3">
        <button onClick={setToday} className="px-3 py-1 rounded-xl border">
          Today
        </button>
        <button onClick={setTomorrow} className="px-3 py-1 rounded-xl border">
          Tomorrow
        </button>
        <button onClick={setWeekend} className="px-3 py-1 rounded-xl border">
          This Weekend
        </button>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {windowDays.map((d, i) => {
          const isSelected = sameDay(d, selected);
          const isToday = sameDay(d, today);
          return (
            <button
              key={i}
              onClick={() => setSelected(d)}
              className={[
                "rounded-2xl p-3 border text-center",
                isSelected ? "border-black shadow" : "border-gray-200",
                isToday ? "font-semibold" : ""
              ].join(" ")}
              aria-pressed={isSelected}
            >
              <div className="text-xs opacity-70">
                {d.toLocaleDateString(undefined, { weekday: "short" })}
              </div>
              <div className="text-xl leading-none">{d.getDate()}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
