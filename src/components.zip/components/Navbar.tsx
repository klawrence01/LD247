// src/components/Navbar.tsx
import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur border-b">
      <nav className="mx-auto max-w-6xl px-4 h-14 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <img src="/logo-ld247.png" alt="LD247" className="h-6 w-auto" />
          <span className="font-semibold">Local Deals 24/7</span>
        </Link>
        <div className="flex items-center gap-6 text-sm">
          <Link href="/sales" className="hover:underline">Sales</Link>
          <Link href="/city/atlanta" className="hover:underline">Atlanta</Link>
          <Link href="/city/hartford" className="hover:underline">Hartford</Link>
        </div>
      </nav>
    </header>
  );
}
