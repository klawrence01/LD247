export default function Hero() {
  return (
    <div>
      <h1>Hello from the Hero component!</h1>
    </div>
  );
}
