export const sampleInsideHustlePosts = [
  {
    id: 1,
    slug: "what-it-takes-to-build",
    title: "What It Takes to Build",
    summary: "The raw, behind-the-scenes truth of starting something from scratch."
  },
  {
    id: 2,
    slug: "meeting-myself-on-the-way-up",
    title: "Meeting Myself on the Way Up",
    summary: "The emotional side of the grind — and what it reveals about you."
  }
];
