export const sampleBehindTheHustlePosts = [
  {
    id: 1,
    slug: "why-i-built-local-deals-247",
    title: "Why I Built Local Deals 24/7",
    summary: "A look at the mission behind the madness — and what made this worth fighting for."
  },
  {
    id: 2,
    slug: "no-corporate-funding-just-faith-and-grit",
    title: "No Corporate Funding — Just Faith and Grit",
    summary: "We’re bootstrapped, mission-led, and building in the wild. This is what it really looks like."
  }
];
